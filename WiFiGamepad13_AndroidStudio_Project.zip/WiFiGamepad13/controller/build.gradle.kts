plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.wifigamepad.controller"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.wifigamepad.controller"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}
