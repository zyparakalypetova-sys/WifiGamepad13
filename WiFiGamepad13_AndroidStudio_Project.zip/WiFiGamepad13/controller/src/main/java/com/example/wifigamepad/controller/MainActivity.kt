package com.example.wifigamepad.controller

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private val port = 38383

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 24)
        window.navigationBarColor = Color.rgb(8, 13, 24)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(8, 13, 24))
        }
        val header = TextView(this).apply {
            text = "WIFI GAMEPAD 13"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(header)
        ip = EditText(this).apply {
            hint = "IP приставки, например 192.168.1.50"
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            textSize = 14f
        }
        root.addView(ip, LinearLayout.LayoutParams(-1, 48))
        val connect = Button(this).apply { text = "Проверить подключение" }
        root.addView(connect)
        status = TextView(this).apply {
            text = "Телефон и приставка должны быть в одной Wi-Fi сети"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(status)

        val playArea = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        left.addView(button("↑", "UP"))
        val drow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        drow.addView(button("←", "LEFT"))
        drow.addView(button("↓", "DOWN"))
        drow.addView(button("→", "RIGHT"))
        left.addView(drow)
        playArea.addView(left, LinearLayout.LayoutParams(0, -1, 1f))

        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER }
        top.addView(button("L1", "L1"))
        top.addView(button("L2", "L2"))
        top.addView(button("R1", "R1"))
        top.addView(button("R2", "R2"))
        middle.addView(top)
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(button("SELECT", "SELECT"))
        bottom.addView(button("START", "START"))
        middle.addView(bottom)
        playArea.addView(middle, LinearLayout.LayoutParams(0, -1, 1f))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row1.addView(button("Y", "BTN_Y"))
        row1.addView(button("X", "BTN_X"))
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(button("B", "BTN_B"))
        row2.addView(button("A", "BTN_A"))
        right.addView(row1)
        right.addView(row2)
        playArea.addView(right, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(playArea, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        connect.setOnClickListener { send("PING") }
    }

    private fun button(title: String, command: String): Button {
        return Button(this).apply {
            text = title
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(25, 91, 153)))
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { send(command); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
            layoutParams = LinearLayout.LayoutParams(68, 62).apply { setMargins(3, 3, 3, 3) }
        }
    }

    private fun send(command: String) {
        val host = ip.text.toString().trim()
        if (host.isBlank()) {
            status.text = "Сначала введи IP приставки"
            return
        }
        thread {
            try {
                DatagramSocket().use { socket ->
                    val bytes = command.toByteArray(Charsets.UTF_8)
                    socket.send(DatagramPacket(bytes, bytes.size, InetAddress.getByName(host), port))
                }
                runOnUiThread { status.text = "Отправлено: $command" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка: ${e.message}" }
            }
        }
    }
}
