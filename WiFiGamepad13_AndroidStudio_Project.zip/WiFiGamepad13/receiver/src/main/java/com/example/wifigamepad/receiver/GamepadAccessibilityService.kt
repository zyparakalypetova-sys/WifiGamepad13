package com.example.wifigamepad.receiver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GamepadAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: GamepadAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun handle(command: String) {
        val point = pointFor(command) ?: return
        val x = (resources.displayMetrics.widthPixels * point.first).toFloat()
        val y = (resources.displayMetrics.heightPixels * point.second).toFloat()
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        dispatchGesture(gesture, null, null)
    }

    // Примерные координаты сенсорных кнопок. Настрой их под конкретную игру.
    private fun pointFor(command: String): Pair<Double, Double>? = when (command) {
        "UP" -> 0.50 to 0.78
        "DOWN" -> 0.50 to 0.94
        "LEFT" -> 0.42 to 0.86
        "RIGHT" -> 0.58 to 0.86
        "BTN_A" -> 0.86 to 0.84
        "BTN_B" -> 0.92 to 0.76
        "BTN_X" -> 0.80 to 0.76
        "BTN_Y" -> 0.86 to 0.68
        "START" -> 0.50 to 0.50
        "SELECT" -> 0.44 to 0.50
        "L1" -> 0.12 to 0.12
        "L2" -> 0.22 to 0.12
        "R1" -> 0.78 to 0.12
        "R2" -> 0.88 to 0.12
        else -> null
    }
}
