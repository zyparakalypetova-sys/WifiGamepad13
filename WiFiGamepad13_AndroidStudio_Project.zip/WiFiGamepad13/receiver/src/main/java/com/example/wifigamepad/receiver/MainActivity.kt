package com.example.wifigamepad.receiver

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import kotlin.concurrent.thread

class MainActivity : Activity() {
    @Volatile private var running = true
    private lateinit var info: TextView
    private var socket: DatagramSocket? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(10, 16, 29))
        }
        info = TextView(this).apply {
            text = "WIFI GAMEPAD RECEIVER\\nПорт: 38383\\nОжидание команд…"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(info)
        val settings = Button(this).apply { text = "Открыть настройки специальных возможностей" }
        settings.setOnClickListener {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(settings)
        val hint = TextView(this).apply {
            text = "Узнай IP приставки в Настройки → Сеть. Введи его в приложении на телефоне."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(hint)
        setContentView(root)
        startServer()
    }

    private fun startServer() {
        thread {
            try {
                socket = DatagramSocket(38383)
                val s = socket ?: return@thread
                while (running) {
                    val data = ByteArray(256)
                    val packet = DatagramPacket(data, data.size)
                    s.receive(packet)
                    val command = String(packet.data, 0, packet.length).trim()
                    runOnUiThread { info.text = "WIFI GAMEPAD RECEIVER\\nПолучено: $command\\nПорт: 38383" }
                    GamepadAccessibilityService.instance?.handle(command)
                }
            } catch (e: Exception) {
                runOnUiThread { info.text = "Ошибка приёма: ${e.message}" }
            }
        }
    }

    override fun onDestroy() {
        running = false
        socket?.close()
        super.onDestroy()
    }
}
